object AppMain extends App {
  println("Hello, World!")
}
