object Maze {
  def solveMaze(maze: List[String]): Option[String] = ???
}
