object ReadAloud extends App {
  def readAloud(lst: List[Int]): List[Int] = ???
  def unreadAloud(rlst: List[Int]): List[Int] = ???
}
