object FilterMap extends App {
  def map[A, B](f: A => B, xs: List[A]): List[B] = ???

  def filter[A](p: A => Boolean, xs: List[A]): List[A] = ???
}
