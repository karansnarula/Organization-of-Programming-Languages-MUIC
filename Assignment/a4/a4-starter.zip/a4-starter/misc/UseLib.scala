package a4

object UseLib extends App {
  def onlyBeginsWithLower(xs: Vector[String]): Vector[String] = ???

  def longestString(xs: Vector[String]): Option[String] = ???

  def longestLowercase(xs: Vector[String]): Option[String] = ???
}
