package a4

object Spaghetti extends App {
  def spaghetti: Stream[String] = ???

  def ham: Stream[String] = ???
}
